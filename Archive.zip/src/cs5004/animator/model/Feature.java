package cs5004.animator.model;

/**
 * This is an empty interface represents the feature used by a Transformation.
 */
public interface Feature {
}
